import React,{useState} from "react";

const Pra =()=>{

    const[data,setData]=useState({
        name:'',
        age:'',
        arr:[],
    });

    const input =(e)=>{
        setData({...data,[e.target.name]:e.target.value});
    };

    const addData =()=>{
        setData({...data,arr:[...data.arr,{name:data.name,age:data.age}]});
        
    };


    return(
        <div>
            <h1>Pra-page...</h1>
            <input type="text" name="name" value={data.name} placeholder="name...." onChange={input} ></input>

            <input type="number" name="age" value={data.age} placeholder="age...." onChange={input} ></input>

            <button onClick={addData}>Submit</button>


            <table>
                <tr>
                    <th>s.no</th>
                    <th>name</th>
                    <th>age</th>
                </tr>

                {data.arr.map((post,i)=>{
                    return(
                        <tr>
                            <td>{i+1}</td>
                            <td>{post.name}</td>
                            <td>{post.age}</td>
                        </tr>
                    )
                })}
            </table>

        </div>
    )
}
export default Pra;