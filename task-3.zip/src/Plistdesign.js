import React from 'react';
import { useParams } from 'react-router-dom';

const Plistdesign = () => {
const data =useParams();
  return (
    <div>
      
      <table border='2'>
        <tr>
            <th>S.no</th>
            <th>title</th>
            <th>category</th>
            <th>Images</th>
            <th>color</th>
            <th>Price</th>
        </tr>
        <tr>
            <td>{data.id}</td>
            <td>{data.pt}</td>
            <td>{data.pcategory}</td>
            <td><img src='{data.image}'/></td>
            <td>{data.pcol}</td>
            <td>{data.pprice}</td>

        </tr>
      </table>
    </div>
  )
}

export default Plistdesign;
