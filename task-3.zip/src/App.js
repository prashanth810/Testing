import logo from './logo.svg';
import './App.css';
import './Samp.css';
import { Link, Route, Routes } from 'react-router-dom';
import Pra from './ab/Pra';
import Sra from './ab/Sra';
import P from './rooting/P';
import Pd from './rooting/Pd';
import Contact from './Contact';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />

        <Contact />

        <Link to='/prashanth'>Pra -(Api) list</Link>

    <Link to='/P'>product list</Link>
    {/* <Link to='/P'>Product</Link> */}

    {/* <Link to='/items'>su</Link> */}
    {/* <Link to='/home'>Home</Link>
    <Link to='/about'>About</Link>    */}

    {/* <Link to='/'>Home</Link>
    <Link to='/about'>About</Link>
     <Link to='/contact'>Contact</Link> */}

       {/*  <Link to="/productlist">Product-list</Link>
        <Link to="/plist">Plist</Link>  */}
        

        <Routes>
          <Route path='/prashanth' element={<Pra />}></Route>

          <Route path='/sra/:pid/:ptitle/pauthor' element={<Sra />}></Route>

          <Route path='/P' element={<P />}></Route>
          {/* <Route path='/ll/:id/:pt/:pimg/:pcat/:pprice' element={<Pd />}></Route> */}
          {/* <Route path='/P' element={<P />}></Route> */}

          <Route path='/Pd/:id/:pt/:image/:pact/:pcol/:price' element={<Pd />}></Route>
        
          {/* <Route path='p-list' element={<Plist />}></Route>

          <Route path='/Plistdesign/:id/:pt/:pcategory/:pcol/:pprice' element={<Plistdesign />}></Route> */}
          
          {/* <Route path='/items' element={<su />}></Route>
        <Route path='/prash/:pid/:pt/:pimg/:pcat/:pcol/:pprice' element={<subu />}></Route> */}

          {/* <Route path='/' element={<Home />}></Route>
          <Route path='/about' element={<About />}></Route>
          <Route path='/abc/:pid/:pimg/:pt/:pcat/:pcolou/:pprice' element={<Contact />}></Route> */}

          {/* <Route path='/' element={<Home />} ></Route>

          <Route path='/about' element={<About />} ></Route> */}

         {/*  <Route path='/abc/:pid/:pimage/:pt/:pcat/:pcolou/:pprice' element={<Contact />}></Route> */}

        </Routes>        
      </header>
     
    </div>
  );
}

export default App;
