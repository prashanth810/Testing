import React from 'react';
import { useParams } from 'react-router-dom';

const Productdesign =()=>{
    const data =useParams();

  return (
    <div>
        {/* Productdesign -{data.pid} -{data.pt}
        -{data.pcategory} */}

            <table border="2">
        <tr>
            <th>S.no</th>
            <th>Productdesign </th>
            <th>Category</th>
            <th>Price</th>
        </tr>
        <tr>
        <td>{data.pid}</td>
        <td>{data.pt} </td>
        <td>{data.pcategory}</td>
        <td>{data.pprice}</td>
        </tr>
  
    </table>  

   </div> 
  )
}

export default Productdesign;
