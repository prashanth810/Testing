import React,{useState} from 'react'
import './Samp.css';

const Home = () => {
    
    const[data,setData]=useState({
        obj:'',
        age:'',
        arr:[],
    });

   const inputchange =(e)=>{
    setData({...data, [e.target.name]:e.target.value});
   };

   const submit =()=>{
    setData({...data,arr:[...data.arr,{obj:data.obj, age:data.age}]});
   };


  return (
    <div>
      <h1>Home Page...</h1>
      
    <input type='text' name='obj' value={data.obj} placeholder='name...' onChange={inputchange} /> 
    <input type='text' name='age' value={data.age} placeholder='age...' onChange={inputchange} />

    <button onClick={submit}>Add</button>

    <table border={2}>
        <tr>
            <th>S.no</th>
            <th>name</th>
            <th>age</th>
        </tr>

        {data.arr.map((post,i)=>{
            return(
                <tr key={i}>
                    <td>{i+1}</td>
                    <td>{post.obj}</td>
                    <td>{post.age}</td>
                </tr>
            )
        })}
    </table>

    </div>
    
  )
}

export default Home;
