import React,{useState} from 'react';
import { Link } from 'react-router-dom';

const About = () => {
    const[count,SetCount]=useState(0);

    const inc=()=>{
        SetCount(count+1);
    };

    const dec =()=>{
        SetCount(count-1);
    };

    const clear=()=>{
        SetCount(0);
    }

  return (
    <div>
      <h1>About Page...</h1>

   <h1> {count}</h1>
      <button onClick={inc}>Inc (+)</button>
      <button onClick={clear}>Reset</button>
      <button onClick={dec} disabled={count == 0}>Inc (-)</button>    
      <button><Link to='/S.js'>Back</Link></button>
    </div>
  )
}

export default About;
