import React from 'react';
import { Link,useParams } from 'react-router-dom';

const subu = () => {
    const{data} = useParams;
  return (
    <div>
        <table>
            <tr>
                <th>S.no</th>
                <th>title</th>
                <th>Title</th>
                <th>category</th>
                <th>colour</th>
                <th>price</th>
            </tr>
            <tr>
                <td>{data.pid}</td>
                <td>{data.pt}</td>
                <td><img src='{data.pimg}'/></td>
                <td>{data.pcat}</td>
                <td>{data.pcol}</td>
                <td>{data.pprice}</td>
            </tr>
        </table>

        <button><Link to='App'>Back</Link></button>
      
    </div>
  )
}

export default subu;
