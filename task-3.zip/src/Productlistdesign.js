import React from "react";
import { useParams } from "react-router-dom";

const Productlistdesign=()=>{
    const data = useParams();
    
    return(
        <div>

        <table border='2'>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>category</th>
                <th>images</th>
                <th>Color</th>
                <th>Price</th>
            </tr>
            <tr>
                <td>{data.pid}</td>
                <td>{data.pt}</td>
                <td>{data.pcat}</td>
                <td><img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYOy9-HJj1E3xhTVdrnhjbhFDc-5c6ETnUUTRpLWkwvkkj6sxvr7vku28WEyHKsYWpxGI&usqp=CAU'></img></td>
                <td>{data.pcolor}</td>
                <td>{data.pprice}</td>
            </tr>
        </table>
        </div>
    )
}
export default Productlistdesign;