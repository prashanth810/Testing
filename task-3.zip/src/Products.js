import React,{useState} from "react";
import { Link } from "react-router-dom";
import './Samp.css';

const Product=()=>{
    const[data,setdata]=useState([{
        id:1,
        title:'Samsung-S23',
        category:'Smart-Phone',
        price:90000
    },
    {
        id:2,
        title:'Iphone',
        category:'Smart-phone',
        price:80000
    },
    {
        id:3,
        title:'mac',
        category:'laptop',
        price:70000
    }
])

    return(
        <div>

            <table border="2">
                <tr>
                    <th>S.no</th>
                    <th>Title</th>
                    <th>Category</th>
                </tr>

                {data.map((post,i)=>{
                    return(
                        <tr key={i}>
                            <td>{i+1}</td>
                        <td>{post.title} 
                        
                        <button>
                            
            <Link to={`/list/${post.id}/${post.title}/${post.category}/${post.price}`}>View</Link>
                </button>

                     </td>
                      <td>{post.category}</td>

                        </tr>
                    )
                })}
            </table>

            <button><a href='Product.js'>Back</a></button>

        </div>

    )
}
export default Product;