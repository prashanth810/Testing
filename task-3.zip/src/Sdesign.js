import React from 'react';
import { useParams } from 'react-router-dom';

const Sdesign = () => {
    const a = useParams();
  return (
    <div>
      <table border='2'>
        <tr>
            <th>S.no</th>
            <thy>Title</thy>
            <th>Imges</th>
            <th>category</th>
            <th>color</th>
            <th>price</th>
        </tr>
        <tr>
            <td>{a.pid}</td>
            <td>{a.pt}</td>
            <td>{a.image}</td>
            <td>{a.pcate}</td>
            <td>{a.pcolour}</td>
            <td>{a.pprice}</td>
        </tr>
      </table>
    </div>
  )
}

export default Sdesign;
