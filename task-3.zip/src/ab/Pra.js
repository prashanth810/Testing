import React,{useState,useEffect} from 'react';
import { Link } from 'react-router-dom';

const Pra = () => {
    const[data,setData] = useState(null);
    const[form,setForm] = useState([
        {title:'', author:''}
    ]);

    const edit =(post)=>setForm(post);

    useEffect(()=>{
        getapi();
    },[]);

    const getapi=()=>{
        fetch(`http://localhost:5000/posts`)
        .then((Response)=> Response.json())
        .then((res)=> setData(res));
    };

    const submitform=(e)=>{
        e.preventDefault();
        const request = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(form),
        };

        fetch(`http://localhost:5000/posts`,request)
        .then((Response)=> Response.json())
        .then((res)=>{
            alert('your data inserted successfully !!');
            setForm({
                title:'',
                author:''
            });
            getapi();
        });
    };

    const updateform=(e)=>{
        e.preventDefault();
        const request = {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title:form.title,
                author:form.author,
            }),
        };

        fetch(`http://localhost:5000/posts/${form.id}`,request)
        .then((Response)=> Response.json())
        .then((res)=>{
            alert('your data updated successfully !!');
            setForm({
                title:'',
                author:'',
            });
            getapi();
        });
    };


    const deleted=(id)=>{
        if(confirm('are you shure ??')){
            const request={
                method:'DELETE',
            };

            fetch(`http://localhost:5000/posts/${id}`,request)
            .then((Response)=> Response.json())
            .then((res)=> {
                alert('data deleted successfully !!');
                getapi();
            });
        };
    };

    const collect=(e)=>{
        setForm({...form,[e.target.name]:e.target.value});
    };

    if(data == null){
        return<p>loading...</p>
    }

  return (
    <div>

        {form.id == undefined ? (

            <form onSubmit={submitform}>
                <input type='text' name='title' value={form.title} placeholder='title...' onChange={collect} /> <br />

                <input type='text' name='author' value={form.author} placeholder='auhtor...' onChange={collect} /> <br />

                <button>Submit</button>
            </form>

        ) : (

           <form onSubmit={updateform}>
                <input type='text' name='title' value={form.title} placeholder='title...' onChange={collect} /> <br />

                <input type='text' name='author' value={form.author} placeholder='auhtor...' onChange={collect} /> <br />

                <button>Submit</button>
            </form>
            
        )}

        <table border='2'>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>author</th>
                <th>Action</th>
            </tr>
            {data.map((post,i)=>{
                return(
                    <tr>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.author}</td>

                        <td>
                            <button onClick={()=> edit(post)}>Edit</button>

                            <button onClick={()=> deleted(post.id)}>Delete</button>

                            <button>
                                <Link to={`/sra/${post.id}/${post.title}/${post.author}`}>View</Link>
                            </button>
                        </td>
                    </tr>
                )
            })}
        </table>
    </div>
  )
}


export default Pra;