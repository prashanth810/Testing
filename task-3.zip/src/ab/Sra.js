import React from 'react';
import { useParams, Link } from 'react-router-dom';

const Sra = () => {
  const data =useParams();
  return (
    <div>
      <table>
        <tr>
          <th>S.no</th>
          <th>title</th>
          <th>author</th>
        </tr>
        <tr>
          <td>{data.pid}</td>
          <td>{data.ptitle}</td>
          <td>{data.pauthor}</td>
        </tr>
      </table>
      
      <button><Link to='./App'>Back</Link></button>
    </div>
  )
}

export default Sra;
