import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Samp.css';
const S = () => {

    const[data,setData]=useState([{
        id:1,
        title:'Samsung-s23 ultra',
        image:<img src='https://miro.medium.com/v2/resize:fill:320:214/0*8WA9lGbo7X8QajzV' />,
        category:'Smart-Phone',
        colour:'Alive green',
        price:80000
    },
    {
        id:2,
        title:'Iphone',
        image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-Q9WtQSzY40wl_706Rni2FLOWQzFJm1C2fg&usqp=CAU'/>,
        category:'Smart-phone',
        colour:'Navy-Blue',
        price:85000        
    },
    {
        id:3,
        title:'Mac-book',
        image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYOy9-HJj1E3xhTVdrnhjbhFDc-5c6ETnUUTRpLWkwvkkj6sxvr7vku28WEyHKsYWpxGI&'/>,
        category:'Laptop',
        colour:'Lime',
        price:85999
    },
    {
        id:4,
        title:'Samsung-Book',
        image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtuI0C14f9dGmqBGh11Oxgad4L38G4Uvib_3-zDFMYy32yoc32V2rGvj_3NyJHaiqt9kk&usqp=CAU'/>,
        category:'Laptop',
        colour:'green',
        price:90999
    }])
  return (
    <div>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <Link class="nav-link active" aria-current="page" to="/">Home</Link>
        </li>
        <li class="nav-item">
        <Link class="nav-link" aria-current="page" to="/about">About</Link>
        </li>
        <li class="nav-item">
        <Link class="nav-link" aria-current="page" to="/contact">Contact</Link>
        </li>
        <li class="nav-item">
        <Link class="nav-link" to="/pra">Pra</Link>
        </li>

        <li class="nav-item">
        <Link class="nav-link" aria-current="page" to="/s-list">slist</Link>
        </li>
      </ul>
    </div>
  </div>
</nav>


        <table border='2'>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>Images</th>
                <th>Action</th>
            </tr>

            {data.map((post,i)=>{
                let imgPath = encodeURI(post.image)
                return(
                    <tr>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.image}</td>
                        <td>
      <button>
   <Link to={`/list/${post.id}/${post.title}/${post.image}/${post.category}/${post.colour}/${post.price}`}>  View-More </Link>
    </button>
                        </td>
                    </tr>
                )
            })}
        </table>

        <button><Link to='/S.js'>Back</Link></button>
      
    </div>
  )
}

export default S;
