import { Link } from "react-router-dom";
import React,{useState} from 'react';

const Home = () => {
  const[data,setData]=useState(0);

  const inc=()=>{
    setData(data + 1);
  };

  const dec =()=>{
    setData(data - 1);
  };
  const rs=()=>{
    setData(0);
  };

  return (
    <div>
      <h2>{data}</h2>
       <button onClick={inc}>Inc +</button>
       <button onClick={dec} disabled={data === 0}>Dec -</button>
       <button onClick={rs}>Reset</button>
      
    <button><Link to='/App' >Back</Link></button>
    </div>

  )
}

export default Home;
