import React from 'react';
import { Link,useParams } from 'react-router-dom';

const Contact = () => {
  const {pid,pt,pcat,image,pcolou,pprice,pimg,} = useParams();
  return (
    <div>

      <table border='2' class='table table-bordered table-'>
        <tr>
          <th>S.no</th>
          <th>image</th>
          <th>Title</th>
          <th>category</th>
          <th>colour</th>
          <th>price</th>
        </tr>
        
        <tr>
          <td>{pid}</td>
          <td><img src='{image}'/></td>
          <td>{pt}</td>
          <td>{pcat}</td>
          <td>{pcolou}</td>
          <td>{pprice}</td>
        </tr>
      </table>
        
        <button><Link to='/About' >Back</Link></button>
      
    </div>
  )
}

export default Contact;
