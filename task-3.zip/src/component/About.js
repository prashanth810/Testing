import React,{useState} from "react";
import { Link } from "react-router-dom";
import '../Samp.css';

const About=()=>{
    const[data,setData]=useState([{
        id:1,
        title:'samsung-s23 ultra',
        image:<img src="https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" />,
        category:'smart-phone',
        colour:'ailve green',
        price:80000
    },
    {
        id:2,
        title:'Iphone-14',
        image:<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVtD4ZVosh2bdcvK9omu4bmbga-Kxo-rYYRg&usqp=CAU" />,
        category:'smart-phone',
        colour:'avilve blue',
        price:85000  
    },
    {
        id:3,
        title:'samsung-book',
        image:<img src="https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" />,
        category:'smart-tab and laptop',
        colour:'navy',
        price:70000
    },
    {
        id:4,
        title:'mac-book air',
        image:<img src="https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" />,
        category:'smart-laptop',
        colour:'silver',
        price:90000
    }])


    return(
        <div>
            
        <table border='2' class='table table-bordered '>
            <tr>
                <th>S.no</th>
                <th>title</th>
                <th>image</th>
                <th>Action</th>
            </tr>

            {data.map((post,i)=>{
                return(
                    <tr key={i}>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.image}</td>
                        <td>
                            <button>

        <Link to={`/abc/${post.id}/${post.image}/${post.title}/${post.category}/${post.colour}/${post.price}`}>View-More</Link>
                            </button>
                        </td>
                    </tr>
                )
            })}

        </table>

        <button type="button"><Link to='/App' >Back</Link></button>
        </div>
    )
}
export default About;