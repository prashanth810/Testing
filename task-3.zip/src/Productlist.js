import React,{useState}  from "react";
import { Link } from "react-router-dom";
import './Samp.css';

const Productlist=()=>{

   const[data,setdata]=useState([{
      id:1,
      title:'Samsung-S23',
      image:<img src='https://miro.medium.com/v2/resize:fill:320:214/0*8WA9lGbo7X8QajzV'></img>,
      category:'Smart-Phone',
      color:'Alive-Green',
      price:80000
   },
   {
    id:2,
    title:'Iphone',
    image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-Q9WtQSzY40wl_706Rni2FLOWQzFJm1C2fg&usqp=CAU'></img>,
    category:'Smar-Phone',
    color:'Lime',
    price:85000
   },
    {
        id:3,
        title:'Mac',
        image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYOy9-HJj1E3xhTVdrnhjbhFDc-5c6ETnUUTRpLWkwvkkj6sxvr7vku28WEyHKsYWpxGI&usqp=CAU'></img>,
        category:'Lapotop',
        color:'Navy-Blue',
        price:89000
    },
    {
        id:4,
        title:'Samsung-Book',
        image:<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtuI0C14f9dGmqBGh11Oxgad4L38G4Uvib_3-zDFMYy32yoc32V2rGvj_3NyJHaiqt9kk&usqp=CAU'></img>,
        category:'Laptop',
        color:'Pure-Silver',
        price:110000
    }
])

return(
    <div>

        <table border='2'>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>Images</th>
                <th>Action</th>
            </tr>
            {data.map((post,i)=>{
                return(
                    <tr key={i}>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.image}</td>
                        <td>
  <button >
    <Link to={`/list/${post.id}/${post.title}/${post.category}/${post.image}/${post.color}/${post.price}`}>View</Link>
  </button>
                        </td>

                    </tr>
                )
            })}
        </table>

        <button><a href="Productlist.js">Back</a></button>
    </div>
)
}
export default Productlist;