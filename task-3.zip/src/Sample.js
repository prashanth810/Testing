import React from 'react';
import { Link } from 'react-router-dom';

const Sample = () => {
  return (
    <div>
      <ol>
        <li><Link to='/'>Home</Link></li>
        <li><Link to='/about'>About</Link></li>
        <li><Link to='/contact'>Contact</Link></li>
      </ol>
    </div>
  )
}

export default Sample;
