import React,{useState} from 'react';
import { Link } from 'react-router-dom';

const P = () => {
    const[data,setData] = useState([
        {
            id:1,
            title:'Samsung - S23 ultra',
            image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
            category:'Smart - Phone',
            colour:'Alive green',
            price:'80000 $'        
        },
        {
            id:2,
            title:'Iphone -14 max',
            image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
            category:'Smart - Phone',
            colour:'green',
            price:'85000 $'
        },
        {
            id:3,
            title:'Samsung - Book',
            image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
            category:'Smart- book',
            colour:'navy',
            price:'90000 $'
        },
        {
            id:4,
            title:'Mac- book',
            image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60' />,
            category:'mac book air',
            colour:'silver',
            price:'95000 $'
        }
    ])
  return (
    <div>

        <table border='2'>
            <tr>
                <th>s.no</th>
                <th>title</th>
                <th>image</th>
                <th>Action</th>
            </tr>

            {data.map((post,i)=>{
                return(
                    <tr>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.image}</td>
                        <td>
                            <button>
                                <Link to={`/Pd/${post.id}/${post.title}/${post.image}/${post.category}/${post.colour}/${post.price}`} >
                                    View
                                </Link>
                            </button>
                        </td>
                    </tr>

                )
            })}
        </table>
      
    </div>
  )
}

export default P;


// import React,{useState} from 'react';
// import { Link } from 'react-router-dom';

// const P = () => {
//     const[data,setData] = useState([
//         {
//             id:1,
//             title:'Samsung-s23 ultra',
//             image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
//             category:'Smart-Phone',
//             colour:'Alive green',
//             price:80000
//         },
//         {
//             id:2,
//             title:'Iphone-14 pro-max',
//             image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
//             category:'Smart-Phone',
//             colour:'yellow',
//             price:85000
//         },
//         {
//             id:3,
//             title:'Samsung-Book',
//             image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
//             category:'Laptop',
//             colour:'Pure silver',
//             price:89000
//         },
//         {
//             id:4,
//             title:'Mack-BooK',
//             image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
//             category:'Laptop',
//             colour:'green',
//             price:90000
//         }
//     ])
//   return (
//     <div>
//       <h2>productlist</h2>

//       <table border='2'>
//         <tr>
//             <th>S.no</th>
//             <th>title</th>
//             <th>image</th>
//             <th>price</th>
//             <th>Action</th>
//         </tr>

//         {data.map((post,i)=>{
//             return(
//                 <tr>
//                     <td>{post.id}</td>
//                     <td>{post.title}</td>
//                     <td>{post.image}</td>
//                     <td>{post.price}</td>
//                     <td>
//                         <button>
//                             <Link to={`/Pd/${post.id}/${post.title}/${post.image}/${post.price}/${post.category}/${post.colour}`}>View</Link>
//                         </button>
//                     </td>
//                 </tr>
//             )
//         })}
//       </table>

//       <button><Link to='./App'>Back</Link></button>
//     </div>
//   )
// }

// export default P;
