import React from 'react'
import { useParams,Link } from 'react-router-dom';

const Pd = () => {
  const data = useParams();
  return (
    <div>
      <table border='2'>
        <tr>
          <th>S.no</th>
          <th>title</th>
          <th>image</th>
          <th>price</th>
          <th>category</th>
          <th>colour</th>
        </tr>
        <tr>
          <td>{data.id}</td>
          <td>{data.pt}</td>
          <td><img src='{data.image}'/></td>
          <td>{data.pact}</td>
          <td>{data.pcol}</td>
          <td class='aaa'>{data.price}</td>
        </tr>
      </table>
      
      <button><Link to='./P'>Back</Link>  </button>
    </div>
  )
}

export default Pd;
