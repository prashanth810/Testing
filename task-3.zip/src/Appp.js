import React from "react";
import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import { Link, Route, Routes } from "react-router-dom";

const Appp =()=>{

 return(
    <div>

        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/contact">Contact</Link>

    <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/contact" element={<Contact />}></Route>
        
    </Routes>
    </div>
 )

}
export default Appp;