import React,{useState} from 'react';
import './Samp.css';

function Contact() {
    const[data,setData]=useState({
        object :'',
        age:'',
        arr:[],
    });

    const inputchange =(e)=>{
        setData({...data,[e.target.name]:e.target.value});
    };

    const addData=()=>{
        setData({...data,arr:[...data.arr,{object:data.object, age:data.age}]});
    };
    

  return (
    <div>
      <h1>Contact page...</h1>
      <input type='text' name='object' value={data.object} placeholder='name...' onChange={inputchange} />
      <input type='number' name='age' value={data.age} placeholder='age...' onChange={inputchange}/>

      <button onClick={addData}>Add</button>


      <table border={3}>
        <tr>
            <th>S.no</th>
            <th>name</th>
            <th>age</th>
        </tr>

        {data.arr.map((post,i)=>{
            return(
                <tr>
                    <td>{i+1}</td>
                    <td>{post.object}</td>
                    <td>{post.age}</td>
                </tr>
            )
        })}
      </table>
    </div>
  )
}

export default Contact;
