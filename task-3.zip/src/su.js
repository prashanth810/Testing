import React,{useState} from 'react';
import { Link } from 'react-router-dom';

const su = () => {
    const[data,setData]=useState([
        {
        id:1,
        title:'Samsung-S23 ultra',
        image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
        category:'Smart-phone',
        colour:'Alive green',
        price:80000
    },
    {
        id:2,
        title:'Iphone-14 pro-max',
        image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
        category:'Smart-phone',
        colour:'pink',
        price:85000
    },
    {
        id:3,
        title:'Mac-book',
        image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
        category:'Smart laptop',
        price:89000
    },
    {
        id:4,
        title:'Samsung-book',
        image:<img src='https://images.unsplash.com/photo-1609252925148-b0f1b515e111?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2Ftc3VuZyUyMHBob25lfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60'/>,
        category:'Smart-book',
        price:90000
    }]);

  return (
    <div>

        <table>
            <tr>
                <th>S.no</th>
                <th>Title</th>
                <th>images</th>
                <th>Action</th>
            </tr>
            {data.map((post,i)=>{
                return(
                    <tr>
                        <td>{post.id}</td>
                        <td>{post.title}</td>
                        <td>{post.image}</td>
                        <td>
                  <button>
        <Link to={`/prash/${post.id}/${post.title}/${post.image}/${post.category}/${post.colour}/${post.price}`}>View-morSe</Link>
                  </button>
                        </td>
                    </tr>
                )
            })}
        </table>
      
    </div>
  )
}

export default su;
